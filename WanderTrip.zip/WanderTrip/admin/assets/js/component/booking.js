/* ============================================================
   DROPDOWN LOGIC — with open/close animation + caret rotation
============================================================ */
function initDropdowns() {
    document.querySelectorAll('.dropbtn').forEach(button => {
        button.addEventListener('click', function (e) {
            e.stopPropagation();

            const dropdown = this.nextElementSibling;
            const isOpen = dropdown.classList.contains('show');

            // Close ALL open dropdowns first (including their carets)
            document.querySelectorAll('.dropdown-content.show').forEach(menu => {
                if (menu !== dropdown) {
                    const otherBtn = menu.previousElementSibling;
                    closeDropdown(menu, otherBtn);
                }
            });

            // Toggle current
            if (isOpen) {
                closeDropdown(dropdown, this);
            } else {
                openDropdown(dropdown, this);
            }
        });
    });
}

function openDropdown(menu, button) {
    menu.style.display = 'flex';

    // Force reflow before adding animation class
    void menu.offsetWidth;

    menu.classList.add('show', 'opening');
    menu.classList.remove('closing');

    // Rotate caret up
    const caret = button.querySelector('i');
    if (caret) caret.classList.add('caret-open');
}

function closeDropdown(menu, button) {
    menu.classList.add('closing');
    menu.classList.remove('opening', 'show');

    // Rotate caret back down
    const caret = button ? button.querySelector('i') : null;
    if (caret) caret.classList.remove('caret-open');

    menu.addEventListener('animationend', function handler() {
        menu.classList.remove('closing');
        menu.style.display = 'none';
        menu.removeEventListener('animationend', handler);
    });
}

// Close all when clicking outside
window.addEventListener('click', function () {
    document.querySelectorAll('.dropdown-content.show, .dropdown-content.closing').forEach(menu => {
        const btn = menu.previousElementSibling;
        closeDropdown(menu, btn);
    });
});

/* ============================================================
   TAB SWITCHING LOGIC
============================================================ */
function initTabs() {
    const tabs = document.querySelectorAll('.appointment-tab');
    const panels = document.querySelectorAll('.tab-panel');

    tabs.forEach(tab => {
        tab.addEventListener('click', function () {
            const target = this.dataset.tab;

            // Remove active from all tabs and panels
            tabs.forEach(t => t.classList.remove('active'));
            panels.forEach(p => p.classList.remove('active'));

            // Set active on clicked tab and matching panel
            this.classList.add('active');
            const targetPanel = document.getElementById(target);
            if (targetPanel) targetPanel.classList.add('active');
        });
    });
}