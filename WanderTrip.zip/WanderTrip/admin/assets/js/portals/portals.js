/* ============================================================
   TOGGLE SWITCH
============================================================ */
const toggle = document.getElementById("modeToggle");
const label = document.getElementById("leftLabel");

function updateToggle() {
    if (toggle.checked) {
        label.innerHTML = '<i class="fa-solid fa-van-shuttle"></i> Van Rental';
    } else {
        label.innerHTML = '<i class="fa-solid fa-plane-departure"></i> Wandertrip';
    }
}
updateToggle();
toggle.addEventListener("change", updateToggle);


/* ============================================================
   SPA SETUP
============================================================ */
const content = document.getElementById('page-content');
const loader = document.getElementById('page-loader');
const links = document.querySelectorAll('.btn-sidebar');

/* ROUTES MAP */
const routes = {
    "#/admin/portals/components/dashboard.html": "/admin/portals/components/dashboard.html",
    "#/admin/portals/components/Bookings.html": "/admin/portals/components/Bookings.html",
    "#/admin/portals/components/Vehicles.html": "/admin/portals/components/Vehicles.html",
    "#/admin/portals/components/Travel&Tours.html": "/admin/portals/components/Travel&Tours.html",
    "#/admin/portals/components/Payments.html": "/admin/portals/components/Payments.html",
    "#/admin/portals/components/Reports.html": "/admin/portals/components/Reports.html",
    "#/admin/portals/components/Customer.html": "/admin/portals/components/Customer.html",
    "#/admin/portals/components/Reviews.html": "/admin/portals/components/Reviews.html",
    "#/admin/portals/components/Settings.html": "/admin/portals/components/Settings.html",
};

const DEFAULT_HASH = "#/admin/portals/components/dashboard.html";
const DEFAULT_PAGE = "/admin/portals/components/dashboard.html";


/* ============================================================
   LOAD PAGE FUNCTION
============================================================ */
function loadPage(page) {
    loader.classList.add('active');
    content.classList.remove('show');

    fetch(page)
        .then(res => res.text())
        .then(html => {
            setTimeout(() => {
                content.innerHTML = html;
                loader.classList.remove('active');
                content.classList.add('show');

                // ✅ Re-initialize component scripts after page injection
                initDropdowns();
                initTabs();
            }, 300);
        })
        .catch(err => {
            content.innerHTML = "<h3>Error loading page</h3>";
            loader.classList.remove('active');
            console.error(err);
        });
}


/* ============================================================
   ACTIVE MENU
============================================================ */
function setActiveLink(hash) {
    links.forEach(link => {
        link.classList.remove('active');
        const parentLi = link.closest('.sidebar-content-inner');
        if (parentLi) parentLi.classList.remove('active');

        const linkHash = '#' + link.getAttribute('href').split('#')[1];

        if (linkHash === hash) {
            link.classList.add('active');
            if (parentLi) parentLi.classList.add('active');
        }
    });
}


/* ============================================================
   HANDLE ROUTE
============================================================ */
function handleRoute() {
    const hash = window.location.hash || DEFAULT_HASH;
    const page = routes[hash] || DEFAULT_PAGE;

    if (!window.location.hash) {
        window.location.hash = DEFAULT_HASH;
        return;
    }

    loadPage(page);
    setActiveLink(hash);
}


/* ============================================================
   SIDEBAR CLICK HANDLER
============================================================ */
links.forEach(link => {
    link.addEventListener('click', function (e) {
        e.preventDefault();
        const fullHref = this.getAttribute('href');
        const hash = '#' + fullHref.split('#')[1];
        window.location.hash = hash;
    });
});


/* ============================================================
   INIT
============================================================ */
window.addEventListener('hashchange', handleRoute);
window.addEventListener('load', handleRoute);