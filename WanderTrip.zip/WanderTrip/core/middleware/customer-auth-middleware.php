 auth checks
 permission gates (runs at top of every page)